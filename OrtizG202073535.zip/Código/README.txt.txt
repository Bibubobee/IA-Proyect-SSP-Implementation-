Compilar con g++ solver.cpp, correr con ./a.out. Pide como input el numero de la instancia a resolver 
(las instancias se encuentran en la carpeta).

El problema se demora más de 2 horas en resolver instancias de 365 días, para que lo consideren.